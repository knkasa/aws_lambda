import boto3
from PIL import Image
import io

def lambda_handler(event, context):
    # Get the S3 bucket and key from the event
    bucket = event['Records'][0]['s3']['bucket']['name']
    key = event['Records'][0]['s3']['object']['key']
    
    # Initialize S3 client
    s3 = boto3.client('s3')
    
    # Download the image in memory
    image_obj = s3.get_object(Bucket=bucket, Key=key)
    image_data = image_obj['Body'].read()
    
    # Resize image
    image = Image.open(io.BytesIO(image_data))
    resized_image = image.resize((800, 600))
    
    # Save and upload the resized image
    buffer = io.BytesIO()
    resized_image.save(buffer, format=image.format)
    s3.put_object(
        Bucket=bucket,
        Key=f'resized/{key}',
        Body=buffer.getvalue()
        )
    
    return {
        'statusCode': 200,
        'body': f'Successfully resized {key}'
        }